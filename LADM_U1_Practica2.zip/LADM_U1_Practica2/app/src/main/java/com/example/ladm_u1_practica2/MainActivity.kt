package com.example.ladm_u1_practica2

import android.content.Context
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        guardar.setOnClickListener {

            if(texto.text.isEmpty() || nombreArchivo.text.isEmpty()){
                mensaje("Llenar todos los campos")
                return@setOnClickListener
            }

            if(memoriaInterna.isChecked){
                guardarArchivoInterno()
            }else{
                permisos()
                guardarArchivoSD()

            }

        }//guardar clickListener

        abrir.setOnClickListener {
            if(memoriaInterna.isChecked){
                leerArchivoInterno()
            }else{
                permisos()
                leerArchivoSD()

            }
        }

    }

    fun guardarArchivoInterno(){
        try {

            var flujoSalida = OutputStreamWriter(openFileOutput(nombreArchivo.text.toString(), Context.MODE_PRIVATE))

            var data = texto.text.toString()

            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()
            mensaje("Awebo! Se Guardó Correctamente")
            borrar()

        }catch (error : IOException){
            mensaje(error.message.toString())
        }
    }

    fun mensaje(m:String){
        AlertDialog.Builder(this).setTitle("ATENCION").setMessage(m).setPositiveButton("OK"){ d, i ->}.show()
    }

    fun borrar(){
        texto.setText("")
        nombreArchivo.setText("")
    }

    fun guardarArchivoSD(){
        if(noSD()){
            mensaje("NO HAY MEMORIA EXTERNA")
            return
        }


        try {

            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivos = File(rutaSD.absolutePath,nombreArchivo.text.toString())


            var flujoSalida = OutputStreamWriter(FileOutputStream(datosArchivos))

            var data = texto.text.toString()

            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()
            mensaje("Awebo! Se Guardó Correctamente")
            borrar()

        }catch (error : IOException){
            mensaje(error.message.toString())
        }

    }

    fun noSD():Boolean {
        var estado = Environment.getExternalStorageState()
        if (estado != Environment.MEDIA_MOUNTED) {
            return true
        } else {
            return false
        }
    }

    fun permisos(){
        if(ContextCompat.checkSelfPermission(this,android.Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_DENIED){
            //codigo para solicitar .ls permisos.

            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    android.Manifest.permission.READ_EXTERNAL_STORAGE),
                0)

        }else{
        }

    }


    fun leerArchivoInterno(){
        try {
            var flujoEntrada = BufferedReader(InputStreamReader(openFileInput(nombreArchivo.text.toString())))

            var data = flujoEntrada.readLine()

            texto.setText(data)

            flujoEntrada.close()


        }catch (error: IOException){
            mensaje(error.message.toString())
        }
    }

    fun leerArchivoSD(){

        if (noSD()){
            mensaje("No HAY MEMORIA EXTERNA")
            return
        }

        try {
            var rutaSD = Environment.getExternalStorageDirectory()
            var datosArchivos = File(rutaSD.absolutePath,nombreArchivo.text.toString())

            var flujoEntrada = BufferedReader(InputStreamReader(FileInputStream(datosArchivos)))

            var data = flujoEntrada.readLine()


            texto.setText(data)

            flujoEntrada.close()


        }catch (error: IOException){
            mensaje(error.message.toString())
        }

    }

}
